"""
Experiential Learning Assignment 02 - Question 4
Titanic Survival Analysis Dashboard
Run with: streamlit run 4_titanic_survival_dashboard.py
"""

import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Titanic Survival Analysis", layout="wide")
st.title("Titanic Survival Analysis Dashboard")

# ---- Load the dataset ----
df = pd.read_csv("../data/titanic.csv")

st.subheader("Dataset Preview (Raw)")
st.dataframe(df.head(10))

# ---- Basic data cleaning ----
# Drop rows missing key values used in this analysis
df_clean = df.dropna(subset=["age", "survived", "pclass", "sex"]).copy()

# Map numeric codes to labels for survival and class
df_clean["survival_status"] = df_clean["survived"].map({0: "Did Not Survive", 1: "Survived"})
df_clean["class_label"] = df_clean["pclass"].map({1: "First", 2: "Second", 3: "Third"})

st.subheader("Cleaned Dataset Preview")
st.dataframe(df_clean[["survival_status", "class_label", "sex", "age"]].head(10))

# ---- Survival rates by class and gender ----
st.subheader("Survival Rate by Passenger Class and Gender")
survival_rates = (
    df_clean.groupby(["class_label", "sex"])["survived"]
    .mean()
    .mul(100)
    .round(2)
    .reset_index()
    .rename(columns={"survived": "survival_rate_%"})
)
st.dataframe(survival_rates)

# ---- Boxplot: age distribution by survival status ----
st.subheader("Age Distribution by Survival Status")
fig1, ax1 = plt.subplots(figsize=(8, 5))
sns.boxplot(data=df_clean, x="survival_status", y="age", ax=ax1)
ax1.set_xlabel("Survival Status")
ax1.set_ylabel("Age")
st.pyplot(fig1)

# ---- Average age for survivors and non-survivors ----
st.subheader("Average Age: Survivors vs Non-Survivors")
avg_age = df_clean.groupby("survival_status")["age"].mean().round(2)
col1, col2 = st.columns(2)
col1.metric("Avg Age - Survived", f"{avg_age.get('Survived', 0):.2f}")
col2.metric("Avg Age - Did Not Survive", f"{avg_age.get('Did Not Survive', 0):.2f}")
