"""
Experiential Learning Assignment 02 - Question 1
Retail Sales Dashboard
Run with: streamlit run 1_retail_sales_dashboard.py
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Retail Sales Dashboard", layout="wide")
st.title("Retail Sales Dashboard")

# ---- Load and preview the dataset ----
df = pd.read_csv("../data/retail_sales.csv", parse_dates=["date"])

st.subheader("Dataset Preview")
st.dataframe(df.head(10))

# ---- Summary statistics of daily revenue ----
st.subheader("Summary Statistics of Daily Revenue")
daily_revenue = df.groupby("date")["revenue"].sum()

col1, col2 = st.columns(2)
col1.metric("Mean Daily Revenue", f"{daily_revenue.mean():,.2f}")
col2.metric("Median Daily Revenue", f"{daily_revenue.median():,.2f}")

# ---- Total units sold and revenue by product category ----
st.subheader("Total Units Sold and Revenue by Product Category")
category_summary = df.groupby("product_category").agg(
    total_units_sold=("units_sold", "sum"),
    total_revenue=("revenue", "sum")
).reset_index().sort_values("total_revenue", ascending=False)

st.dataframe(category_summary)

# ---- Line chart: daily revenue trend over time ----
st.subheader("Daily Revenue Trend Over Time")
fig1, ax1 = plt.subplots(figsize=(10, 4))
ax1.plot(daily_revenue.index, daily_revenue.values, color="teal")
ax1.set_xlabel("Date")
ax1.set_ylabel("Revenue")
ax1.set_title("Daily Revenue Trend")
st.pyplot(fig1)

# ---- Bar chart: total revenue by product category ----
st.subheader("Total Revenue by Product Category")
fig2, ax2 = plt.subplots(figsize=(8, 4))
ax2.bar(category_summary["product_category"], category_summary["total_revenue"], color="coral")
ax2.set_xlabel("Product Category")
ax2.set_ylabel("Total Revenue")
ax2.set_title("Total Revenue by Category")
st.pyplot(fig2)
