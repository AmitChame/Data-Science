"""
Experiential Learning Assignment 02 - Question 2
Student Grades Explorer
Run with: streamlit run 2_student_grades_explorer.py
"""

import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Student Grades Explorer", layout="wide")
st.title("Student Grades Explorer")

# ---- Load and preview the dataset ----
df = pd.read_csv("../data/student_grades.csv")

st.subheader("Dataset Preview")
st.dataframe(df.head(10))

# ---- Dropdown to select a subject ----
subjects = sorted(df["subject"].unique())
selected_subject = st.selectbox("Select a Subject", subjects)

subject_df = df[df["subject"] == selected_subject]

# ---- Summary statistics for the selected subject ----
st.subheader(f"Summary Statistics for {selected_subject}")
col1, col2, col3 = st.columns(3)
col1.metric("Mean Final Score", f"{subject_df['final_score'].mean():.2f}")
col2.metric("Median Final Score", f"{subject_df['final_score'].median():.2f}")
col3.metric("Std Dev of Final Score", f"{subject_df['final_score'].std():.2f}")

# ---- Boxplot: final score distributions across subjects ----
st.subheader("Final Score Distribution Across Subjects")
fig1, ax1 = plt.subplots(figsize=(9, 5))
sns.boxplot(data=df, x="subject", y="final_score", ax=ax1)
ax1.set_xlabel("Subject")
ax1.set_ylabel("Final Score")
st.pyplot(fig1)

# ---- Scatterplot: Test1 vs Final Score for the selected subject ----
st.subheader(f"Test1 vs Final Score - {selected_subject}")
fig2, ax2 = plt.subplots(figsize=(8, 5))
sns.scatterplot(data=subject_df, x="test1", y="final_score", hue="subject", ax=ax2)
ax2.set_xlabel("Test1 Score")
ax2.set_ylabel("Final Score")
st.pyplot(fig2)
