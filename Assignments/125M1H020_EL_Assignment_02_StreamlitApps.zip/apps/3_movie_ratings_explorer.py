"""
Experiential Learning Assignment 02 - Question 3
Movie Ratings Explorer
Run with: streamlit run 3_movie_ratings_explorer.py
"""

import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Movie Ratings Explorer", layout="wide")
st.title("Movie Ratings Explorer")

# ---- Load and preview the dataset ----
df = pd.read_csv("../data/movie_ratings.csv")

st.subheader("Dataset Preview (Raw)")
st.dataframe(df.head(10))

# ---- Drop rows with missing values in key columns ----
key_columns = ["genre", "rating", "votes", "year"]
df_clean = df.dropna(subset=key_columns)

st.write(f"Rows before cleaning: {len(df)} | Rows after dropping missing key values: {len(df_clean)}")

# ---- Dropdown to select a genre ----
genres = sorted(df_clean["genre"].unique())
selected_genre = st.selectbox("Select a Genre", genres)

genre_df = df_clean[df_clean["genre"] == selected_genre]

# ---- Summary statistics for the selected genre ----
st.subheader(f"Summary Statistics for {selected_genre}")
col1, col2, col3 = st.columns(3)
col1.metric("Average Rating", f"{genre_df['rating'].mean():.2f}")
col2.metric("Average Votes", f"{genre_df['votes'].mean():,.0f}")
col3.metric("Median Release Year", f"{genre_df['year'].median():.0f}")

# ---- Boxplot: rating distribution across all genres ----
st.subheader("Rating Distribution Across All Genres")
fig1, ax1 = plt.subplots(figsize=(9, 5))
sns.boxplot(data=df_clean, x="genre", y="rating", ax=ax1)
ax1.set_xlabel("Genre")
ax1.set_ylabel("Rating")
st.pyplot(fig1)

# ---- Scatterplot: Votes vs Rating for selected genre ----
st.subheader(f"Votes vs Rating - {selected_genre}")
fig2, ax2 = plt.subplots(figsize=(8, 5))
scatter = ax2.scatter(
    genre_df["votes"], genre_df["rating"],
    s=genre_df["votes"] / genre_df["votes"].max() * 300 + 20,
    c=genre_df["rating"], cmap="viridis", alpha=0.7
)
ax2.set_xlabel("Votes")
ax2.set_ylabel("Rating")
fig2.colorbar(scatter, ax=ax2, label="Rating")
st.pyplot(fig2)
