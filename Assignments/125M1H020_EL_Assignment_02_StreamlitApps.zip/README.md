# Advanced Data Science Lab [MCA33PE21]
## Experiential Learning Assignment 02 — Streamlit WebApp Development

**PRN:** 125M1H020
**Name:** Amit Chame
**Class:** SYMCA (Semester I)
**Assignment Date:** 30/07/2026
**Submission Date:** 05/08/2026

---

### Folder Structure

```
EL2/
├── apps/
│   ├── 1_retail_sales_dashboard.py
│   ├── 2_student_grades_explorer.py
│   ├── 3_movie_ratings_explorer.py
│   └── 4_titanic_survival_dashboard.py
├── data/
│   ├── retail_sales.csv
│   ├── student_grades.csv
│   ├── movie_ratings.csv
│   └── titanic.csv
├── requirements.txt
└── README.md
```

> Each dataset is sample/synthetic data generated to match the column structure described in the
> assignment (retail sales, student grades, movie ratings). `titanic.csv` is the standard, publicly
> available Titanic dataset. If your instructor has provided the official datasets via the
> assignment's "Download" links, simply replace the corresponding CSV file in the `data/` folder —
> the apps will work unchanged as long as the column names match.

### How to Run

1. Install dependencies (Python 3.9+ recommended):
   ```bash
   pip install -r requirements.txt
   ```
2. From inside the `apps/` folder, run any app with Streamlit:
   ```bash
   cd apps
   streamlit run 1_retail_sales_dashboard.py
   streamlit run 2_student_grades_explorer.py
   streamlit run 3_movie_ratings_explorer.py
   streamlit run 4_titanic_survival_dashboard.py
   ```
3. Streamlit will open the app in your browser (default: http://localhost:8501).

---

### Question 1 — Retail Sales Dashboard
Loads and previews a daily retail sales dataset, shows mean/median daily revenue, a
category-wise summary table of units sold and revenue, a line chart of the daily revenue
trend, and a bar chart comparing total revenue across product categories.

### Question 2 — Student Grades Explorer
Loads and previews a student grades dataset, lets the user pick a subject from a dropdown,
shows mean/median/std of the final score for that subject, a boxplot comparing final score
distributions across all subjects, and a scatterplot of Test1 vs Final Score for the
selected subject.

### Question 3 — Movie Ratings Explorer
Loads and previews a movie ratings dataset, drops rows with missing values in key columns,
lets the user pick a genre from a dropdown, shows average rating / average votes / median
release year for that genre, a boxplot comparing rating distributions across all genres, and
a scatterplot of Votes vs Rating for the selected genre (vote count as marker size, rating as
color gradient).

### Question 4 — Titanic Survival Analysis Dashboard
Loads and cleans the Titanic dataset (drops missing values, maps numeric survival/class codes
to readable labels), computes survival rate by passenger class and gender, shows a boxplot of
age distribution by survival status, and displays the average age of survivors vs
non-survivors.

---

**Prof. Prakash Ukhalkar**
Course Teacher, Advanced Data Science Lab
